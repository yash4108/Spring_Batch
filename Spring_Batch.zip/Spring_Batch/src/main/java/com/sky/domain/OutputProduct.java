package com.sky.domain;

import java.util.Objects;

public class OutputProduct {
	private String productId;
	private String productName;
	private int price;


	public OutputProduct() {
		// TODO Auto-generated constructor stub
	}
	
	

	public int getPrice() {
		return price;
	}



	public void setPrice(int price) {
		this.price = price;
	}



	public OutputProduct(String productId, String productName, int price) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.price = price;
	}


	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	@Override
	public int hashCode() {
		return Objects.hash(productId, productName);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OutputProduct other = (OutputProduct) obj;
		return Objects.equals(productId, other.productId) && Objects.equals(productName, other.productName);
	}

	@Override
	public String toString() {
		return "OutputProduct [productId=" + productId + ", productName=" + productName + "]";
	}

}
