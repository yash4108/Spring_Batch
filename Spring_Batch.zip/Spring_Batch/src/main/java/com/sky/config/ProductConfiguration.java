package com.sky.config;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

import com.sky.domain.OutputProduct;
import com.sky.domain.Product;
import com.sky.processor.ProductItemProcessor;

@Configuration
@EnableBatchProcessing
public class ProductConfiguration {

	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;
	// end::setup[]
	@Bean
	public FlatFileItemReader<Product> reader() {
		return new FlatFileItemReaderBuilder<Product>()
			.name("productItemReader")
			.resource(new ClassPathResource("sample-product.csv"))
			.delimited()
			.names(new String[]{"productId", "productName","price"})
			.fieldSetMapper(new BeanWrapperFieldSetMapper<Product>() {{
				setTargetType(Product.class);
			}})
			.build();
	}

	
	@Bean
	public  ItemProcessor<Product, OutputProduct> processor(){
		return new ProductItemProcessor();
	}
	
	@Bean
	public ItemWriter<Product> writer(DataSource dataSource){
		JdbcBatchItemWriter<Product>writer=new JdbcBatchItemWriter<Product>();
		
		writer.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>());
		
		writer.setSql("INSERT INTO product(product_Id,product_Name,price)VALUES  (:productId,:productName,:price)");
		writer.setDataSource(dataSource);
		return writer;
	}
	
	
	@Bean
	public Step step1(JdbcBatchItemWriter<OutputProduct> writer) {
		return stepBuilderFactory.get("step1")
			.<Product, OutputProduct> chunk(10)
			.reader(reader())
			.processor(processor())
			.writer(writer)
			.build();
	}
	
	@Bean
	public Job importUserJob(Step step1) {
		return jobBuilderFactory.get("importUserJob")
			.incrementer(new RunIdIncrementer())
		
			.flow(step1)
			.end()
			.build();
	}
}
